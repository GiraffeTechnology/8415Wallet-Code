import 'server-only';
const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 18)) throw Error('ARTFI_LISTING_NODE_22_18_REQUIRED');
import { readFileSync } from 'node:fs';
export * from './dist/scripts/task-runtime/server.mjs';
export const runtimeManifest = Object.freeze(JSON.parse(readFileSync(new URL('./runtime-manifest.json', import.meta.url), 'utf8')));
